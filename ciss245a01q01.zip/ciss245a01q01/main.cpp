/*
Dustin Meckley
ciss245
homework1.cpp
*/

#include <iostream>
#include <vector>
#include <algorithm>														

// Method Prototypes:
int count(std::vector<int>, int);											
int linearSearch(std::vector<int>, int);										
int binarySearch(std::vector<int>, int);									
void normalize(std::vector<double>);

const int TEN = 10;													

int main()
{
	std::vector<int> a = {3, 4, 3, 1, 2};						

	// Count Method Call:
	std::cout << count({3, 4, 3, 1, 2}, 3) << std::endl; 				

	// Linear Search Method Call:
	std::cout << linearSearch({3, 4, 3, 1, 2}, 4) << std::endl; 		

	// Binary Search Method Call:
	std::vector<int> b = {5, 4, 3, 2, 1};														
	std::cout << binarySearch(b, 4) << std::endl; 

	// Normalize Method Call:
	std::vector<double> c = {1.0, 2.0, 1.0, 6.0};													
	normalize({1.0, 2.0, 1.0, 6.0}); 												
	
	return 0;															
}

// Count Method Definition:
int count(std::vector<int> a, int target)
{
	int count = 0;														
	std::vector<int>::iterator i;								
	for (auto i = a.begin(); i != a.end(); i++) {				
		if (*i == target) {
			count++;													
		}
	}
	return count;														
}

// Linear Search Method Definition:
int linearSearch(std::vector<int> a, int target)
{ 
   	for (auto i : a) {  										
   		if ( a.at(i) == target) { 
   			return i;
   		}
   }
   return -1;											
}

// Binary Search Method Definition:
int binarySearch(std::vector<int> b, int target)
{
	std::sort(b.begin(), b.end());								
   	int first = 0, last = b.size() - 1;
   	while (first <= last) {
   		int middle = (first + last) / 2;  
       	if (target > b.at(middle)) {
       		first = middle + 1;  
       	} 
       	else if (target < b.at(middle)) {
       		last = middle - 1; 
       	} 
       	else {
       		return middle;     
       	}
   }
   return -(first + 1);    												
}

// Normalize Method Definition:
void normalize(std::vector<double> c)
{		
	std::vector<int>::iterator i;								
	for (auto i = c.begin(); i != c.end(); i++) {				
		std::cout << *i / 10 << ' ';						
	}	
	std::cout << std::endl;
}




