// Name: Dustin Meckley
// File: a11q01.cpp

#include <iostream>
#include <vector>

void displayVector(std::vector<int>);

int main()
{
    std::vector<int> x = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};    
    displayVector({0, 0, 0, 0, 0, 0, 0, 0, 0, 0});          

    int index = 0, value = 0;    
    do
    {
        std::cout << "index and new value: ";
        std::cin >> index;
        if (index == -1)
            break;
        std::cin >> value;
        x.at(index) = value;
        displayVector(x);
        std::cout << std::endl; 
    } while (1);
    displayVector(x);
    std::cout << std::endl;

    return 0;
}

// Range-based for loop and auto keyword utilized:
void displayVector(std::vector<int> x) {
    std::cout << "vector: ";
    for(auto i : x) {                                       
        std::cout << i << " ";   
    }
    std::cout << std::endl;
}